
@attribute_should_not_be_a_function("word")
class A
{
	@nested_attribute_should_not_be_a_function("word")
	int function()
	{
		
	}
}