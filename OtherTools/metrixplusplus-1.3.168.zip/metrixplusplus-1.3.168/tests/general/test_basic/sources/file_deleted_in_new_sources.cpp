

/*
 * Just produce any code in order to test basic workflow
 */
namespace hmm
{

class B
{

	B()
	{
		/* first funtion */
		this->m_member = 10;
		if (a & "asdadasdsd")
		{
			int a; // right?
		}
	}

};

}

int never_old(int how_long = 999)
{
	while(true)
	{

	}
	return 1;
}
