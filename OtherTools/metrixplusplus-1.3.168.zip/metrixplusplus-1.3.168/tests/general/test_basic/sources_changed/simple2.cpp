

// Just produce any code in order to test basic workflow
namespace hmm
{

class New_A
{

	New_A()
	{
		/* first funtion */
		this->m_member = 10;
		if (a & b)
		{
			for (int i = 0; i < 0 && i > 0; i++)
			{
				// crazy, right?
			}
		}
	}

};

}
