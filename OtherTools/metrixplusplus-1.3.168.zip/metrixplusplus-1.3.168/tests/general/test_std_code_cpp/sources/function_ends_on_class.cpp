
namespace my_namespace {

class my_class {
	int function_end_on_class()
	{

	}
	int function_end_on_struct()
	{

	}
	int function_end_on_namespace()
	{

	}
};

}
